DUZZI MEMORY SITE
=================

This is a free, self-contained mini website.

Files:
- index.html
- images/memory-1.jpg ... memory-6.jpg

To test it:
1. Keep the folder structure unchanged.
2. Open index.html in a browser.

To publish it for free:
- Upload the folder to a GitHub repository and enable GitHub Pages, or
- Upload the folder to another free static-hosting service.

You can replace the images in /images while keeping the same filenames.
